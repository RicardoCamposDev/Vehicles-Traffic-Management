#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define max 50 //Definir maximo de caracteres de cada string
#define num_reg 100 //Definir maximo de registos a ler

//Estrutura para guardar os dados de cada registo lido
struct Registo{

    char matricula[max];
    char tipo;
    int velocidade;
    char via[max];
    char local[max];
};

struct Registo reg[num_reg]; //Array de estruturas para guardar cada registo inserido
FILE *fp; //iniciar apontador de Ficheiro

//Declaracao dos cabe�alhos das funcoes usadas no programa
int Menu();
void escreverFicheiro(int tReg, int nReg);
void encontrarRegisto();
void eliminarFicheiro();

int main()
{
    int sair = 0; //Variavel que permite sair do programa
    int num = 0; //Numero de registos a ler
    int total_reg = 0; //Guarda o total de registos lidos
    int numRegFich = 0;
    int totalRegFich = 0;

    do{
        switch(Menu()){
            case 1:
                printf("\nNumero de registos a ler: ");
                scanf("%d", &num);

                total_reg = total_reg + num; //total de registos lidos/inseridos

                for(int i = 0, pos = (total_reg - num); i < num; i++){ //Ciclo que permite guardar os dados de cada registo no array de estruturas
                        printf("\nRegisto %d\n", (i + 1));
                        printf("Matricula:\n");
                        scanf("%s", &reg[pos].matricula);
                        fflush(stdin); //limpa o buffer de entrada do teclado
                        printf("Tipo:\n");
                        scanf("%c", &reg[pos].tipo);
                        printf("Velocidade:\n");
                        scanf("%d", &reg[pos].velocidade);
                        printf("Via:\n");
                        scanf("%s", &reg[pos].via);
                        printf("Local:\n");
                        scanf("%s", &reg[pos].local);
                        pos+=1;
                }
            break;
            case 2:
                printf("\nImprimir Registos:\n");

                if(total_reg > 0){
                        for(int j = 0; j < total_reg; j++){ //Ciclo que permite mostrar todos os registos lidos
                            printf("\nRegisto %d\n", (j + 1));
                            printf("Matricula: %s\n", reg[j].matricula);
                            printf("Tipo: %c\n", reg[j].tipo);
                            printf("Velocidade: %d\n", reg[j].velocidade);
                            printf("Via: %s\n", reg[j].via);
                            printf("Local: %s\n", reg[j].local);
                        }
                }else{
                    printf("\nAinda nao existem registos!!!!\n");
                }
            break;
            case 3:
                printf("\nNumero de registos a ler: "); //Numero de registos a inserir no Ficheiro
                scanf("%d", &numRegFich);
                totalRegFich = totalRegFich + numRegFich; //total de registos lidos/inseridos

                escreverFicheiro(totalRegFich, numRegFich);
            break;
            case 4:
                encontrarRegisto();
            break;
            case 5:
                eliminarFicheiro(); //Eliminar manualmente o Ficheiro
            break;
            case 0:
                sair = 1; //Sair do programa
            break;
        }

    }while(!sair);

    return 0;
}

int Menu(){ //Implementacao da funcao que apresenta o menu de opcoes ao utilizador

    int opcao = 0;

    printf("\n************************* Registos Informacao Sensor *****************************\n");
    printf("\n----- Fase 1 ----\n");
    printf("\n1.Ler Registos.\n");
    printf("2.Imprimir Registos.\n");
    printf("\n---- Fase 2 -----\n");
    printf("3.Ler Registos para Ficheiro.\n");
    printf("4.Verificar Registos de uma dada matricula.\n");
    printf("5.Eliminar Ficheiro.\n");
    printf("0.Sair.\n");
    printf("\nIntroduza a opcao desejada:\n");
    scanf("%d", &opcao);

    while(opcao < 0 || opcao > 5)
    {
        printf("\nOpcao errada!! Por favor introduza nova opcao:\n");
        scanf("%d", &opcao);
    }

    return opcao;
}

////////////// Implementacao das funcoes que manipulam o Ficheiro //////////////////////////////////////

void escreverFicheiro(int tReg, int nReg){ //Funcao para escrever os registos no ficheiro

    //NOTA: variavel tReg guarda o numero total de registos no ficheiro. A variavel nReg guarda o numero de registos a ler inseridos pelo utilizador

    if((fp = fopen("registosTeste.txt", "a"))==NULL){
                printf("Impossivel abrir ficheiro!!");
    }else{
            fprintf(fp, "%d\n",tReg); //Guarda no Ficheiro o numero total de registos e vai actualizando ao serem feitos novos registos
        for(int i = 0, index = (tReg - nReg); i < nReg; i++){ //Ciclo que permite guardar os dados de cada registo no Ficheiro
            printf("\nRegisto %d\n", (i + 1));
            printf("Matricula:\n");
            scanf("%s", &reg[index].matricula);
            fprintf(fp, "%s ", reg[index].matricula);
            fflush(stdin); //limpa o buffer de entrada do teclado
            printf("Tipo:\n");
            scanf("%c", &reg[index].tipo);
            fprintf(fp, "%c ", reg[index].tipo);
            printf("Velocidade:\n");
            scanf("%d", &reg[index].velocidade);
            fprintf(fp, "%d ", reg[index].velocidade);
            printf("Via:\n");
            scanf("%s", &reg[index].via);
            fprintf(fp, "%s ", reg[index].via);
            printf("Local:\n");
            scanf("%s", &reg[index].local);
            fprintf(fp, "%s\n", reg[index].local);
            index+=1;
        }
    }

    fclose(fp);
}

void encontrarRegisto(){ //Funcao para ler uma dada matricula e verificar o numero de registos da mesma

    char fich[max];
    char numMatricula[max];
    int numRegistos = 0;
    int k = 0;

    printf("\nNome do ficheiro:\n");
    scanf("%s", &fich);
    printf("\nNumero da Matricula:\n");
    scanf("%s", &numMatricula);

    rewind(fp); //Coloca a posicao do ficheiro no inicio

    if((fp = fopen(fich, "r"))==NULL){
                printf("\nImpossivel abrir Ficheiro!! O Ficheiro possivelmente nao existe!!!\n");
    }else{

            while (!feof(fp)) { //Executa o ciclo enquanto nao chega ao fim do ficheiro

                fscanf(fp, "%s", reg[k].matricula); //Vai ler todas as matriculas

                if (strcmp(reg[k].matricula , numMatricula) == 0) { //Faz a comparacao da matricula introduzida com as existentes no Ficheiro

                    numRegistos+=1; //Conta o numero de registos da matricula
                }
                k+=1;
            }
    }
    printf("\nNumero de registos: %d\n", numRegistos); //Apresenta o numero de registos da matricula
    fclose(fp);
}

void eliminarFicheiro(){ //Funcao para eliminar Ficheiro

    int del_file = remove("registosTeste.txt");

    if(!del_file){
        printf("\nO ficheiro foi eliminado com sucesso!\n");
    }else{
        printf("\nERRO!!O ficheiro nao foi eliminado!!!!\n");
    }
}
